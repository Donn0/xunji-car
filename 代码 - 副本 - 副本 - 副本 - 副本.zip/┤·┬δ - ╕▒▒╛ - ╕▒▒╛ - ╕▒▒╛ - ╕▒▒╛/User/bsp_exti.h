#ifndef __BSP_EXTI_H
#define __BSP_EXTI_H

#include "stm32f10x.h"
#define KEY0_INT_GPIO_Pin    GPIO_Pin_1
#define KEY0_INT_GPIO_PORT   GPIOB
#define KEY0_INT_GPIO_CLK    RCC_APB2Periph_GPIOB
void Exti_Key_Config(void);
#endif __BSP_EXTI_H
