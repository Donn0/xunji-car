#ifndef __MOTOR_H
#define __MOTOR_H

#include "stm32f10x.h"

void Motor_Gpio_Init(void);
void Motor_LF_forward(u8 speed);
void Motor_LF_backward(u8 speed);
void Motor_LF_Stop(void);
void Motor_LB_forward(u8 speed);
void Motor_LB_backward(u8 speed);
void Motor_LB_Stop(void);
void Motor_RF_forward(u8 speed);
void Motor_RF_backward(u8 speed);
void Motor_RF_Stop(void);
void Motor_RB_forward(u8 speed);
void Motor_RB_backward(u8 speed);
void Motor_RB_Stop(void);
void Car_Stop(void);			// С��=ֹͣ(Ϩ��/ɲ��)
void Car_forward(u8 speed);				// С����ǰ(�ٶ� = speed%)
void Car_backward(u8 speed);			// С�����(�ٶ� = -speed%)
void cg(void);
void Car_Turn_Left(u8 speed);			// С����ת(�ٶ� = speed%)
void Car_Turn_Right(u8 speed);			// С����ת(�ٶ� = speed%)
#endif
