#include "Motor.h"
#include "trail.h"
void Motor_Gpio_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;  				// �����������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	
	GPIO_Init(GPIOA, &GPIO_InitStructure);	
  //GPIO_Init(GPIOB, &GPIO_InitStructure);	
  GPIO_WriteBit(GPIOA,GPIO_Pin_1 ,1);
	//GPIO_WriteBit(GPIOA,GPIO_Pin_8 ,1);
}

void Motor_LF_forward(u8 speed)
{
	GPIO_WriteBit(GPIOA,GPIO_Pin_2 ,1);
	GPIO_WriteBit(GPIOA,GPIO_Pin_3 ,0);
	TIM_SetCompare1(TIM4, speed);
}

void Motor_LF_backward(u8 speed)
{
	GPIO_WriteBit(GPIOA,GPIO_Pin_2 ,0);
	GPIO_WriteBit(GPIOA,GPIO_Pin_3 ,1);
	TIM_SetCompare1(TIM4, speed);
}

void Motor_LF_Stop(void)
{
	GPIO_WriteBit(GPIOA,GPIO_Pin_2 ,1);
	GPIO_WriteBit(GPIOA,GPIO_Pin_3 ,1);
	//TIM_SetCompare1(TIM4, speed);
}
void Motor_RF_forward(u8 speed)
{
	GPIO_WriteBit(GPIOA,GPIO_Pin_4 ,1);
	GPIO_WriteBit(GPIOA,GPIO_Pin_5 ,0);
	TIM_SetCompare2(TIM4, speed);
}

void Motor_RF_backward(u8 speed)
{
	GPIO_WriteBit(GPIOA,GPIO_Pin_4 ,0);
	GPIO_WriteBit(GPIOA,GPIO_Pin_5 ,1);
	TIM_SetCompare2(TIM4, speed);
}

void Motor_RF_Stop(void)
{
	GPIO_WriteBit(GPIOA,GPIO_Pin_4 ,1);
	GPIO_WriteBit(GPIOA,GPIO_Pin_5 ,1);
	//TIM_SetCompare2(TIM4, speed);
}
void Motor_LB_forward(u8 speed)
{
	GPIO_WriteBit(GPIOA,GPIO_Pin_9 ,1);
	GPIO_WriteBit(GPIOA,GPIO_Pin_10 ,0);
	TIM_SetCompare3(TIM4, speed);
}

void Motor_LB_backward(u8 speed)
{
	GPIO_WriteBit(GPIOA,GPIO_Pin_9 ,0);
	GPIO_WriteBit(GPIOA,GPIO_Pin_10 ,1);
	TIM_SetCompare3(TIM4, speed);
}

void Motor_LB_Stop(void)
{
	GPIO_WriteBit(GPIOA,GPIO_Pin_9 ,1);
	GPIO_WriteBit(GPIOA,GPIO_Pin_10 ,1);
	//TIM_SetCompare3(TIM4, speed);
}
void Motor_RB_forward(u8 speed)
{
	GPIO_WriteBit(GPIOA,GPIO_Pin_11 ,1);
	GPIO_WriteBit(GPIOA,GPIO_Pin_12 ,0);
	TIM_SetCompare4(TIM4, speed);
}

void Motor_RB_backward(u8 speed)
{
	GPIO_WriteBit(GPIOA,GPIO_Pin_11 ,0);
	GPIO_WriteBit(GPIOA,GPIO_Pin_12 ,1);
	TIM_SetCompare4(TIM4, speed);
}

void Motor_RB_Stop(void)
{
	GPIO_WriteBit(GPIOA,GPIO_Pin_11 ,1);
	GPIO_WriteBit(GPIOA,GPIO_Pin_12 ,1);
	//TIM_SetCompare4(TIM4, speed);
}

void Car_forward(u8 speed)
{
	Motor_LF_forward(speed);
	Motor_LB_forward(speed);
			
	Motor_RF_forward(speed);
	Motor_RB_forward(speed);
}

void Car_backward(u8 speed)
{
	Motor_LF_backward(speed);
	Motor_LB_backward(speed);
					
	Motor_RF_backward(speed);
	Motor_RB_backward(speed);
}

void Car_Turn_Left(u8 speed)
{
	Motor_LF_backward(speed);
	Motor_LB_backward(speed);
			
	Motor_RF_forward(speed);
	Motor_RB_forward(speed);
}

void Car_Turn_Right(u8 speed)
{
	Motor_LF_forward(speed);
	Motor_LB_forward(speed);
			
	Motor_RF_backward(speed);
	Motor_RB_backward(speed);
}

void Car_Stop(void)
{
	Motor_LB_Stop();
	Motor_LF_Stop();
	Motor_RB_Stop();
	Motor_RF_Stop();
}

void cg(void)
{
  Trail_black_line();		// ���߼�⺯��
		if( S_Trail_Input == Middle_Find_Black_Line )
			{
				Motor_LF_forward(55);
	Motor_LB_forward(55);
			
	Motor_RF_forward(50);
	Motor_RB_forward(50);
			}
		
			// ��෢�ֺ���
			//----------------------------------------------
			else if( S_Trail_Input == Left_Find_Black_Line || S_Trail_Input == Left_Middle_Find_Black_Line )
			{
				Car_Turn_Left(75);	// ��ת
			}
			
			// �Ҳ෢�ֺ���
			//----------------------------------------------
		else if( S_Trail_Input == Right_Find_Black_Line || S_Trail_Input == Right_Middle_Find_Black_Line )
			{
					Motor_LF_forward(100);
	Motor_LB_forward(100);
			
	Motor_RF_backward(100);
	Motor_RB_backward(100);
			}
}